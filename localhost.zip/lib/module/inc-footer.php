<footer>
<div class="footer-con-container">
	<div class="footer-con-overlay darkmode-header">
		<div class="wavebar-con-container">
			<div class="wavebar-con-wrap">
				<div class="wavebar-svg-object">
				</div>
				<div class="wavebar-svg-object">
				</div>
			</div>
		</div>
		<div class="footer-con-header">
			<div class="footer-con-outer">
				<div class="footer-con-inner">
					<div class="footer-ico-logo darkmode-footer-logo">
					</div>
					<table class="footer-table-out">
					<tr>
						<td>
							<div class="footer-table-in">
								<div class="footer-con-bound">
									<div class="footer-tx1-bound">
										<span>Main</span>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://yt3.ggpht.com/ytc/AAUvwngEGOkqv88Nc7c724emLh1t_s-gFFet6lj4MhNf=s900-c-k-c0x00ffffff-no-rj">
										<span>блох</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://yt3.ggpht.com/ytc/AAUvwngEGOkqv88Nc7c724emLh1t_s-gFFet6lj4MhNf=s900-c-k-c0x00ffffff-no-rj">
										<span>в</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://yt3.ggpht.com/ytc/AAUvwngEGOkqv88Nc7c724emLh1t_s-gFFet6lj4MhNf=s900-c-k-c0x00ffffff-no-rj">
										<span>а</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://yt3.ggpht.com/ytc/AAUvwngEGOkqv88Nc7c724emLh1t_s-gFFet6lj4MhNf=s900-c-k-c0x00ffffff-no-rj">
										<span>с</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://yt3.ggpht.com/ytc/AAUvwngEGOkqv88Nc7c724emLh1t_s-gFFet6lj4MhNf=s900-c-k-c0x00ffffff-no-rj">
										<span>и</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://yt3.ggpht.com/ytc/AAUvwngEGOkqv88Nc7c724emLh1t_s-gFFet6lj4MhNf=s900-c-k-c0x00ffffff-no-rj">
										<span>л</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://yt3.ggpht.com/ytc/AAUvwngEGOkqv88Nc7c724emLh1t_s-gFFet6lj4MhNf=s900-c-k-c0x00ffffff-no-rj">
										<span>и</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://yt3.ggpht.com/ytc/AAUvwngEGOkqv88Nc7c724emLh1t_s-gFFet6lj4MhNf=s900-c-k-c0x00ffffff-no-rj">
										<span>й</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://yt3.ggpht.com/ytc/AAUvwngEGOkqv88Nc7c724emLh1t_s-gFFet6lj4MhNf=s900-c-k-c0x00ffffff-no-rj">
										<span>а</span>
										</a>
									</div>
								</div>
							</div>
						</td>
						<td>
							<div class="footer-table-in">
								<div class="footer-con-bound">
									<div class="footer-tx1-bound">
										<span>а</span>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://yt3.ggpht.com/ytc/AAUvwngEGOkqv88Nc7c724emLh1t_s-gFFet6lj4MhNf=s900-c-k-c0x00ffffff-no-rj">
										<span>м</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://yt3.ggpht.com/ytc/AAUvwngEGOkqv88Nc7c724emLh1t_s-gFFet6lj4MhNf=s900-c-k-c0x00ffffff-no-rj">
										<span>в</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://yt3.ggpht.com/ytc/AAUvwngEGOkqv88Nc7c724emLh1t_s-gFFet6lj4MhNf=s900-c-k-c0x00ffffff-no-rj">
										<span>е</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://yt3.ggpht.com/ytc/AAUvwngEGOkqv88Nc7c724emLh1t_s-gFFet6lj4MhNf=s900-c-k-c0x00ffffff-no-rj">
										<span>й</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://yt3.ggpht.com/ytc/AAUvwngEGOkqv88Nc7c724emLh1t_s-gFFet6lj4MhNf=s900-c-k-c0x00ffffff-no-rj">
										<span>к</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://yt3.ggpht.com/ytc/AAUvwngEGOkqv88Nc7c724emLh1t_s-gFFet6lj4MhNf=s900-c-k-c0x00ffffff-no-rj">
										<span>а</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://yt3.ggpht.com/ytc/AAUvwngEGOkqv88Nc7c724emLh1t_s-gFFet6lj4MhNf=s900-c-k-c0x00ffffff-no-rj">
										<span>а</span>
										</a>
									</div>
								</div>
							</div>
						</td>
						<td>
							<div class="footer-table-in">
								<div class="footer-con-bound">
									<div class="footer-tx1-bound">
										<span>Social</span>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://yt3.ggpht.com/ytc/AAUvwngEGOkqv88Nc7c724emLh1t_s-gFFet6lj4MhNf=s900-c-k-c0x00ffffff-no-rj">
										<span>Discord</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://yt3.ggpht.com/ytc/AAUvwngEGOkqv88Nc7c724emLh1t_s-gFFet6lj4MhNf=s900-c-k-c0x00ffffff-no-rj">
										<span>нет</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://www.youtube.com/channel/UCNmYLoCFACetKMM67tnY5og/videos">
										<span>ладно</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="">
										<span>нит</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="">
										<span>тоже нит</span>
										</a>
									</div>
								</div>
							</div>
						</td>
						<td class="footer-con-sources">
							<div class="footer-table-in">
								<div class="footer-con-bound">
									<div class="footer-tx1-bound">
										<span>репа</span>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://artmoskovia.ru/wp-content/uploads/2016/10/1P1190771.jpg">
										<span>репа</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://www.povarenok.ru/images/recipes/step/35/3575/357502.jpg">
										<span>репа</span>
										</a>
									</div>
									<div class="footer-tx2-bound">
										<a href="https://sun9-33.userapi.com/sun9-14/impg/cFGDE-S98Oz-992TIBZTxchLWS1CM6a6VibpbQ/GjWtp99eEjA.jpg?size=512x469&quality=96&sign=d6776e0c4c1078154ddbdec0d7747620&type=album">
										<span>ииии</span>
										</a>
									</div>
								</div>
							</div>
						</td>
					</tr>
					</table>
				</div>
			</div>
		</div>
		<div class='footer-con-credits'>
			<div class="footer-con-outer">
				<div class="footer-con-inner">
					<div class='footer-con-seprator'>
					</div>
					<div class="footer-con-foot">
						<div class="footer-con-side">
							<div class="footer-tx1-founder">
								<div class="footer-ico-developer" style="background: url('/img/open.png') center center / cover no-repeat;">
								</div>
								<a href="https://avatars.mds.yandex.net/i?id=3af7ad8ce36957eea6d5aec2e749e766-5235832-images-thumbs&ref=rim&n=33&w=150&h=150">
								<span>Я</span>
								</a>
							</div>
						</div>
						<div class="footer-con-side">
							<div class="footer-tx1-webmaster">
								<div class="footer-ico-developer" style="background: url('/img/open.png') center / cover no-repeat;">
								</div>
								<a href="https://pbs.twimg.com/media/D6eqSpfXkAE-WPk.jpg">
								<span>и я</span>
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</footer>