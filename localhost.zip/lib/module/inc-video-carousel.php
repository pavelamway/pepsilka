<div class="container fill">
	<div id="myCarousel" class="carousel slide">
		<div class="carousel-inner">
			<!-- Carousel Slide -->
			<div class="item active">
				<div class="fill">
					<div class="video-con-container">
						<div class='video-con-left'>
							<div class='video-con-wrapper'>
								<div class="video-btn-play">
								</div>
								<div class="video-ico-service">
								</div>
								<div class='video-con-animate page-video-1'>
								</div>
								<div class='video-img-thumbnail' style="background: url('/img/1.jpg') no-repeat center; background-size: cover;">
								</div>
							</div>
						</div>
						<div class='video-con-right'>
							<div class="video-tx1-description darkmode-txt scale-content-txt-4">
								<div class='video-emp-block'>
								</div>
								<h2>2 дня пытался видео добавить, а оказалось легко</h2>
								<h3>Я пытался, но у меня получилось.</h3>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- Carousel Slide -->
			<div class="item">
				<div class="fill">
					<div class="video-con-container">
						<div class='video-con-left'>
							<div class='video-con-wrapper'>
								<div class="video-btn-play">
								</div>
								<div class="video-ico-service">
								</div>
								<div class='video-con-animate page-video-2'>
								</div>
								<div class='video-img-thumbnail' style="background: url('/img/videos/2.jpg') no-repeat center; background-size: cover;">
								</div>
							</div>
						</div>
						<div class='video-con-right'>
							<div class="video-tx1-description darkmode-txt scale-content-txt-5">
								<div class='video-emp-block'>
								</div>
								<h2>нет</h2>
								<h3>речлама</h3>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- Carousel Slide -->
			<div class="item">
				<div class="fill">
					<div class="video-con-container">
						<div class='video-con-left'>
							<div class='video-con-wrapper'>
								<div class="video-btn-play">
								</div>
								<div class="video-ico-service">
								</div>
								<div class='video-con-animate page-video-3'>
								</div>
								<div class='video-img-thumbnail' style="background: url('/img/videos/3.jpg') no-repeat center; background-size: cover;">
								</div>
							</div>
						</div>
						<div class='video-con-right'>
							<div class="video-tx1-description darkmode-txt scale-content-txt-6">
								<div class='video-emp-block'>
								</div>
								<h2>не позволю</h2>
								<h3>що це</h3>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>